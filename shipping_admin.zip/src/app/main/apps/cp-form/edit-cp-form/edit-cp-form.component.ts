import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-cp-form',
  templateUrl: './edit-cp-form.component.html',
  styleUrls: ['./edit-cp-form.component.scss']
})
export class EditCpFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
