import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-cp-form',
  templateUrl: './add-cp-form.component.html',
  styleUrls: ['./add-cp-form.component.scss']
})
export class AddCpFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
