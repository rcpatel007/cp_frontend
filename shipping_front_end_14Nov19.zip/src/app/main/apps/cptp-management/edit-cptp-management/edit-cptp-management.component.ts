import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-cptp-management',
  templateUrl: './edit-cptp-management.component.html',
  styleUrls: ['./edit-cptp-management.component.scss']
})
export class EditCptpManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
