// export const apiUrl = 'http://34.244.52.149:81/api';

export const config = {
    production: false,
    // baseUrl: 'http://3.89.115.24:3008/api'
    baseUrl: 'http://localhost:3001/api'
    // baseUrl: 'http://18.219.59.88:3001/api'
};
